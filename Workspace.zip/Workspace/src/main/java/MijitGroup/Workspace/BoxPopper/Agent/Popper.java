/*
 * Copyright (C) 2020 mijitr <MijitR.xyz>
 *
 * Dis How Ballers Do...
 */
package MijitGroup.Workspace.BoxPopper.Agent;

/**
 *
 * @author mijitr <MijitR.xyz>
 */
public class Popper {
    
}
