/*
 * Copyright (C) 2020 mijitr <MijitR.xyz>
 *
 * Dis How Ballers Do...
 */
package MijitGroup.Workspace.Math;

/**
 *
 * @author mijitr <MijitR.xyz>
 */
public enum Op {
    PAD, CUT
}
